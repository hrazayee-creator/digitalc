(function (root) {
  'use strict';
  var ACC = [
    ["#D8B76A", "#F3DB9C", "#1B1405"], ["#2563EB", "#60A5FA", "#FFFFFF"], ["#10B981", "#6EE7B7", "#04281D"],
    ["#F43F5E", "#FB7185", "#FFFFFF"], ["#8B5CF6", "#C4B5FD", "#FFFFFF"], ["#F97316", "#FDBA74", "#2A1204"],
    ["#14B8A6", "#5EEAD4", "#032421"], ["#334155", "#94A3B8", "#FFFFFF"]
  ];
  var ICONS = {
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    mail: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
    globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    pin: '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    user: '<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>',
    insta: '<rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>',
    linkedin: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
    send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    chev: '<polyline points="15 18 9 12 15 6"/>'
  };
  var PHOTO_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/;

  function svg(n) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + ICONS[n] + '</svg>';
  }
  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined && txt !== null) e.textContent = txt;
    return e;
  }
  function icon(cls, name) { var s = el('span', cls); s.innerHTML = svg(name); return s; }

  // ---- payload decoding (offline "smart links") ----
  function b64ToBytes(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var bin = atob(s), a = new Uint8Array(bin.length), i;
    for (i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
    return a;
  }
  function bytesToStr(a) {
    var s = '', i;
    for (i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function decodePayload(p, cb) {
    try {
      var kind = p.charAt(0), bytes = b64ToBytes(p.slice(1));
      if (kind === 'u') { cb(null, bytesToStr(bytes)); return; }
      if (kind === 'z') {
        if (typeof DecompressionStream === 'undefined' || typeof Response === 'undefined') { cb('old'); return; }
        var stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        new Response(stream).arrayBuffer().then(function (buf) { cb(null, bytesToStr(new Uint8Array(buf))); }, function () { cb('bad'); });
        return;
      }
      cb('bad');
    } catch (e) { cb('bad'); }
  }
  function parse(str) {
    var f = str.split('\u001f'), v = f.slice(2), i;
    for (i = 0; i < 13; i++) if (v[i] === undefined) v[i] = '';
    return { t: parseInt(f[0], 10) || 0, a: parseInt(f[1], 10) || 0, v: v };
  }

  // ---- helpers ----
  function fixUrl(u) { u = (u || '').replace(/^\s+|\s+$/g, ''); return /^https?:\/\//i.test(u) ? u : (u ? 'https://' + u : ''); }
  function social(base, v) { if (/^https?:\/\//i.test(v)) return v; return base + encodeURIComponent(v.replace(/^@/, '')); }
  function digits(s) { return (s || '').replace(/[^0-9]/g, ''); }
  function host(u) { return u.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0]; }
  function vesc(s) { return s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n'); }
  function vcard(v) {
    var L = ['BEGIN:VCARD', 'VERSION:3.0', 'N:;' + vesc(v[0] || '-') + ';;;', 'FN:' + vesc(v[0] || '-')];
    if (v[2]) L.push('ORG:' + vesc(v[2]));
    if (v[1]) L.push('TITLE:' + vesc(v[1]));
    if (v[4]) L.push('TEL;TYPE=CELL:' + vesc(v[4]));
    if (v[5]) L.push('EMAIL:' + vesc(v[5]));
    if (v[6]) L.push('URL:' + vesc(fixUrl(v[6])));
    if (v[11]) L.push('ADR;TYPE=WORK:;;' + vesc(v[11]) + ';;;;');
    if (v[3]) L.push('NOTE:' + vesc(v[3]));
    L.push('END:VCARD');
    return L.join('\r\n') + '\r\n';
  }
  function customLinks(text) {
    var out = [], lines = (text || '').split('\n'), i, ln, k, label, url;
    for (i = 0; i < lines.length; i++) {
      ln = lines[i].replace(/^\s+|\s+$/g, '');
      if (!ln) continue;
      k = ln.lastIndexOf('|');
      if (k >= 0) { label = ln.slice(0, k).replace(/\s+$/, ''); url = fixUrl(ln.slice(k + 1)); }
      else { url = fixUrl(ln); label = host(url); }
      if (url) out.push([label || host(url), url]);
    }
    return out;
  }

  /** card = {t: template 0-5, a: accent 0-7, v: [13 strings], p: optional data-URL photo} */
  function render(card, app) {
    var v = card.v || [], acc = ACC[card.a] || ACC[0], tpl = card.t >= 0 && card.t <= 5 ? card.t : 0, i;
    for (i = 0; i < 13; i++) if (typeof v[i] !== 'string') v[i] = '';
    app.innerHTML = '';
    var page = el('div', 'page t' + tpl);
    page.style.setProperty('--a', acc[0]);
    page.style.setProperty('--a2', acc[1]);
    page.style.setProperty('--on', acc[2]);
    page.appendChild(el('div', 'cover'));
    var wrap = el('div', 'card'), box = el('div', 'box');
    var name = v[0] || 'کارت دیجیتال';
    var av = el('div', 'avatar');
    if (typeof card.p === 'string' && PHOTO_RE.test(card.p)) {
      var im = document.createElement('img');
      im.src = card.p;
      im.alt = '';
      av.appendChild(im);
    } else {
      av.textContent = name.charAt(0);
    }
    box.appendChild(av);
    var head = el('div', 'head');
    head.appendChild(el('h1', '', name));
    var sub = v[1];
    if (v[2]) sub = sub ? sub + ' · ' + v[2] : v[2];
    if (sub) head.appendChild(el('div', 'sub', sub));
    box.appendChild(head);
    if (v[3]) box.appendChild(el('p', 'bio', v[3]));

    var quick = el('div', 'quick'), qn = 0;
    function q(icn, href, label) {
      var a = el('a', 'q'); a.href = href; a.setAttribute('aria-label', label);
      a.innerHTML = svg(icn);
      if (/^https?:/.test(href)) { a.target = '_blank'; a.rel = 'noopener'; }
      quick.appendChild(a); qn++;
    }
    if (v[4]) q('phone', 'tel:' + v[4].replace(/\s/g, ''), 'تماس');
    if (v[9]) q('chat', 'https://wa.me/' + digits(v[9]), 'واتساپ');
    if (v[8]) q('send', social('https://t.me/', v[8]), 'تلگرام');
    if (v[7]) q('insta', social('https://instagram.com/', v[7]), 'اینستاگرام');
    if (v[5]) q('mail', 'mailto:' + v[5], 'ایمیل');
    if (qn) box.appendChild(quick);

    var save = el('a', 'save');
    save.href = 'data:text/vcard;charset=utf-8,' + encodeURIComponent(vcard(v));
    save.setAttribute('download', 'contact.vcf');
    save.innerHTML = svg('user');
    save.appendChild(el('span', '', 'ذخیره در مخاطبین'));
    box.appendChild(save);

    function row(icn, title, subtitle, href) {
      var a = el('a', 'row'); a.href = href;
      if (/^https?:/.test(href)) { a.target = '_blank'; a.rel = 'noopener'; }
      a.appendChild(icon('ico', icn));
      var rt = el('div', 'rt'); rt.appendChild(el('b', '', title));
      if (subtitle) rt.appendChild(el('small', '', subtitle));
      a.appendChild(rt);
      a.appendChild(icon('chev', 'chev'));
      box.appendChild(a);
    }
    if (v[6]) row('globe', 'وب‌سایت', host(fixUrl(v[6])), fixUrl(v[6]));
    if (v[10]) { var li = /^https?:/i.test(v[10]) ? v[10] : 'https://linkedin.com/in/' + encodeURIComponent(v[10]); row('linkedin', 'لینکدین', host(li), li); }
    if (v[11]) row('pin', 'آدرس', v[11], 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(v[11]));
    var cl = customLinks(v[12]);
    for (i = 0; i < cl.length; i++) row('link', cl[i][0], host(cl[i][1]), cl[i][1]);

    wrap.appendChild(box);
    page.appendChild(wrap);
    app.appendChild(page);
    if (app.ownerDocument === document) document.title = name;
  }

  function message(app, txt) {
    app.innerHTML = '';
    app.appendChild(el('div', 'msg', txt));
  }

  var DEMO = '1\u001f1\u001fنمونه کارت\u001fمدیر محصول\u001fشرکت شما\u001fاین یک کارت نمونه است. کارت خودتان را بسازید و لینکش را به اشتراک بگذارید.\u001f09120000000\u001fname@example.com\u001fexample.com\u001fmy_id\u001fmy_id\u001f989120000000';

  root.CardRender = {
    ACC: ACC, render: render, message: message, parse: parse, decodePayload: decodePayload,
    customLinks: customLinks, vcard: vcard, DEMO: DEMO, PHOTO_RE: PHOTO_RE
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.CardRender;
})(typeof window !== 'undefined' ? window : globalThis);
