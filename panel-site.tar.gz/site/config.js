// Fill these two values after creating your Supabase project (Project Settings -> API Keys).
// URL: https://xxxxxxxx.supabase.co     KEY: the "publishable" key (sb_publishable_...) or the legacy "anon" key.
// Both are meant to be public; all protection is inside the database.
window.CFG = {
  URL: "https://YOUR-PROJECT.supabase.co",
  KEY: "YOUR-PUBLISHABLE-KEY"
};
