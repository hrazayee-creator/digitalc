(function (root) {
  'use strict';
  var CFG = root.CFG || {};
  var SKEY = 'cd_admin_session';

  function configured() {
    return !!(CFG.URL && CFG.KEY && CFG.URL.indexOf('YOUR-') < 0 && CFG.KEY.indexOf('YOUR-') < 0);
  }
  function headers(token) {
    var h = { 'apikey': CFG.KEY, 'Content-Type': 'application/json' };
    if (token) h['Authorization'] = 'Bearer ' + token; // only a real user token, never the publishable key
    return h;
  }
  function call(url, opts) {
    return fetch(url, opts).then(function (res) {
      return res.text().then(function (t) {
        var body = null;
        try { body = t ? JSON.parse(t) : null; } catch (e) { body = null; }
        if (!res.ok) {
          var m = (body && (body.message || body.msg || body.error_description || body.error)) || ('HTTP ' + res.status);
          var err = new Error(m);
          err.status = res.status;
          err.code = body && body.code;
          throw err;
        }
        return body;
      });
    });
  }
  function readSession() {
    try { return JSON.parse(localStorage.getItem(SKEY) || 'null'); } catch (e) { return null; }
  }
  function saveSession(s) {
    if (!s || !s.access_token) throw new Error('پاسخ ورود نامعتبر است');
    var sess = {
      access_token: s.access_token,
      refresh_token: s.refresh_token,
      expires_at: s.expires_at ? s.expires_at * 1000 : Date.now() + (s.expires_in || 3600) * 1000
    };
    try { localStorage.setItem(SKEY, JSON.stringify(sess)); } catch (e) { /* private mode */ }
    return sess;
  }

  var Api = {
    configured: configured,
    rpc: function (name, params, token) {
      return call(CFG.URL + '/rest/v1/rpc/' + name, { method: 'POST', headers: headers(token), body: JSON.stringify(params || {}) });
    },
    login: function (email, password) {
      return call(CFG.URL + '/auth/v1/token?grant_type=password',
        { method: 'POST', headers: headers(), body: JSON.stringify({ email: email, password: password }) }).then(saveSession);
    },
    logout: function () { try { localStorage.removeItem(SKEY); } catch (e) { } },
    hasSession: function () { return !!readSession(); },
    /** Resolves a valid access token (refreshing it if needed) or null. */
    token: function () {
      var s = readSession();
      if (!s) return Promise.resolve(null);
      if (s.expires_at - Date.now() > 60000) return Promise.resolve(s.access_token);
      return call(CFG.URL + '/auth/v1/token?grant_type=refresh_token',
        { method: 'POST', headers: headers(), body: JSON.stringify({ refresh_token: s.refresh_token }) })
        .then(function (r) { return saveSession(r).access_token; })
        .catch(function () { Api.logout(); return null; });
    },
    /** Calls an admin function with the logged-in user's token. */
    admin: function (name, params) {
      return Api.token().then(function (t) {
        if (!t) { var e = new Error('نشست شما منقضی شده؛ دوباره وارد شوید'); e.status = 401; throw e; }
        return Api.rpc(name, params, t);
      });
    }
  };
  root.Api = Api;
})(window);
