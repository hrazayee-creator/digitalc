(function () {
  'use strict';
  var root = document.getElementById('root');
  var BASE = location.origin + location.pathname.replace(/[^\/]*$/, '');
  var items = [], filter = '', toastTimer;

  function h(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function toast(msg, err) {
    var old = document.querySelector('.s-toast'); if (old) old.remove();
    var t = h('div', 's-toast' + (err ? ' err' : ''), msg); document.body.appendChild(t);
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.remove(); }, 3500);
  }
  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { toast('کپی شد'); }, function () { toast('کپی نشد', true); });
    else toast('کپی نشد', true);
  }
  function pubLink(slug) { return BASE + '#@' + slug; }
  function editLink(key) { return BASE + 'studio.html#' + key; }
  function date(x) { try { return new Date(x).toLocaleDateString('fa-IR'); } catch (e) { return String(x).slice(0, 10); } }
  function errText(e) {
    if (e && (e.status === 401 || e.code === '42501')) return 'دسترسی مجاز نیست؛ دوباره وارد شوید';
    return (e && e.message) || 'خطای نامشخص';
  }
  function handle(e) {
    if (e && (e.status === 401 || e.code === '42501')) { Api.logout(); showLogin(); }
    toast(errText(e), true);
  }

  // ---------------------------------------------------------------- login
  function showLogin(note) {
    root.innerHTML = '';
    var c = h('div', 's-card'); c.appendChild(h('h2', '', 'ورود مدیر'));
    if (!Api.configured()) { c.appendChild(h('p', 's-muted', 'سرور هنوز تنظیم نشده است (فایل config.js را کامل کنید).')); root.appendChild(c); return; }
    if (note) c.appendChild(h('p', 's-muted', note));
    c.appendChild(h('label', 's-lbl', 'ایمیل'));
    var em = h('input', 's-in s-ltr'); em.type = 'email'; em.autocomplete = 'username'; c.appendChild(em);
    c.appendChild(h('label', 's-lbl', 'رمز عبور'));
    var pw = h('input', 's-in s-ltr'); pw.type = 'password'; pw.autocomplete = 'current-password'; c.appendChild(pw);
    var go = h('button', 's-btn gold', 'ورود'); go.style.marginTop = '14px'; go.style.width = '100%';
    function submit() {
      go.disabled = true;
      Api.login(em.value.trim(), pw.value).then(function () { return Api.admin('is_admin'); }).then(function (ok) {
        go.disabled = false;
        if (!ok) { Api.logout(); toast('این حساب مدیر نیست', true); return; }
        showDash();
      }, function (e) { go.disabled = false; toast(e.status === 400 ? 'ایمیل یا رمز اشتباه است' : errText(e), true); });
    }
    go.onclick = submit; pw.onkeydown = function (e) { if (e.key === 'Enter') submit(); };
    c.appendChild(go); root.appendChild(c);
  }

  // ---------------------------------------------------------------- dashboard
  function showDash() {
    root.innerHTML = '';
    var bar = h('div', 's-row');
    var out = h('button', 's-btn sm line', 'خروج'); out.onclick = function () { Api.logout(); showLogin(); };
    var bk = h('button', 's-btn sm line', 'دانلود پشتیبان'); bk.onclick = backup;
    var rf = h('button', 's-btn sm line', 'تازه‌سازی'); rf.onclick = load;
    bar.appendChild(rf); bar.appendChild(bk); bar.appendChild(out); root.appendChild(bar);

    // create
    var cc = h('div', 's-card'); cc.appendChild(h('h2', '', 'مشتری جدید'));
    cc.appendChild(h('label', 's-lbl', 'نام مشتری (فقط برای خودت)'));
    var lab = h('input', 's-in'); lab.placeholder = 'مثلاً: دکتر احمدی'; cc.appendChild(lab);
    cc.appendChild(h('label', 's-lbl', 'آدرس دلخواه کارت (اختیاری، انگلیسی: a-z 0-9 -)'));
    var slug = h('input', 's-in s-ltr'); slug.placeholder = 'dr-ahmadi'; cc.appendChild(slug);
    cc.appendChild(h('label', 's-lbl', 'مدت اعتبار'));
    var days = h('select', 's-sel');
    [['', 'نامحدود'], ['30', '۳۰ روز'], ['90', '۹۰ روز'], ['365', '۱ سال']].forEach(function (o) { days.appendChild(new Option(o[1], o[0])); });
    days.value = '365'; cc.appendChild(days);
    var mk = h('button', 's-btn gold', 'ساخت کارت'); mk.style.marginTop = '14px'; mk.style.width = '100%';
    var res = h('div');
    mk.onclick = function () {
      mk.disabled = true;
      Api.admin('admin_create', { p_label: lab.value.trim(), p_slug: slug.value.trim() || null, p_days: days.value ? +days.value : null }).then(function (r) {
        mk.disabled = false; lab.value = ''; slug.value = '';
        showCreated(res, 'کارت ساخته شد', r.slug, r.key); load();
      }, function (e) { mk.disabled = false; handle(e); });
    };
    cc.appendChild(mk); cc.appendChild(res); root.appendChild(cc);

    // list
    var lc = h('div', 's-card'); lc.appendChild(h('h2', '', 'مشتریان'));
    var se = h('input', 's-in'); se.placeholder = 'جستجو (نام یا آدرس)'; se.oninput = function () { filter = se.value.trim().toLowerCase(); renderList(); };
    lc.appendChild(se);
    var list = h('div', 's-table'); list.id = 'list'; lc.appendChild(list); root.appendChild(lc);
    load();
  }

  function showCreated(box, title, slug, key) {
    box.innerHTML = '';
    var c = h('div'); c.style.marginTop = '14px'; c.style.borderTop = '1px dashed #cdd5e3'; c.style.paddingTop = '10px';
    c.appendChild(h('div', 'nm', title + ' — ' + slug));
    c.appendChild(h('div', 's-muted', 'لینک ویرایش (برای مشتری؛ فقط همین یک بار نمایش داده می‌شود):'));
    c.appendChild(h('div', 's-link', editLink(key)));
    var r1 = h('div', 's-row'); var b1 = h('button', 's-btn sm gold', 'کپی لینک ویرایش'); b1.onclick = function () { copy(editLink(key)); }; r1.appendChild(b1); c.appendChild(r1);
    c.appendChild(h('div', 's-muted', 'لینک کارت (بعد از فعال‌سازی باز می‌شود):'));
    c.appendChild(h('div', 's-link', pubLink(slug)));
    var r2 = h('div', 's-row'); var b2 = h('button', 's-btn sm line', 'کپی لینک کارت'); b2.onclick = function () { copy(pubLink(slug)); }; r2.appendChild(b2); c.appendChild(r2);
    box.appendChild(c);
  }

  function load() {
    Api.admin('admin_list').then(function (r) { items = r || []; renderList(); }, handle);
  }

  function status(it) {
    var exp = it.expires_at ? new Date(it.expires_at) : null;
    if (exp && exp < new Date()) return ['bad', 'منقضی'];
    if (it.active) return ['ok', 'فعال'];
    return ['wait', 'در انتظار فعال‌سازی'];
  }

  function act(name, params, okMsg) {
    return Api.admin(name, params).then(function (r) { if (okMsg) toast(okMsg); load(); return r; }, handle);
  }

  function renderList() {
    var list = document.getElementById('list'); if (!list) return;
    list.innerHTML = '';
    var shown = items.filter(function (it) {
      var s = ((it.label || '') + ' ' + (it.name || '') + ' ' + it.slug).toLowerCase();
      return !filter || s.indexOf(filter) >= 0;
    });
    if (!shown.length) { list.appendChild(h('p', 's-muted', items.length ? 'موردی پیدا نشد.' : 'هنوز مشتری‌ای ثبت نشده است.')); return; }
    shown.forEach(function (it) {
      var st = status(it), row = h('div', 'it');
      var top = h('div', 's-row'); top.appendChild(h('span', 'nm', it.label || it.name || '(بدون نام)')); top.appendChild(h('span', 's-chip ' + st[0], st[1]));
      row.appendChild(top);
      var info = 'آدرس: ' + it.slug + ' · بازدید: ' + it.views + (it.expires_at ? ' · اعتبار تا: ' + date(it.expires_at) : ' · نامحدود');
      if (it.name && it.label && it.name !== it.label) info += ' · نام روی کارت: ' + it.name;
      row.appendChild(h('div', 's-muted', info));
      var b = h('div', 's-row');
      var tg = h('button', 's-btn sm ' + (it.active ? 'line' : 'gold'), it.active ? 'غیرفعال کن' : 'فعال کن');
      tg.onclick = function () { act('admin_update', { p_slug: it.slug, p_active: !it.active }, it.active ? 'غیرفعال شد' : 'فعال شد'); };
      var e30 = h('button', 's-btn sm line', '+۳۰ روز'); e30.onclick = function () { act('admin_update', { p_slug: it.slug, p_days: 30 }, '۳۰ روز تمدید شد'); };
      var e365 = h('button', 's-btn sm line', '+۱ سال'); e365.onclick = function () { act('admin_update', { p_slug: it.slug, p_days: 365 }, 'یک سال تمدید شد'); };
      var nl = h('button', 's-btn sm line', 'نامحدود'); nl.onclick = function () { act('admin_update', { p_slug: it.slug, p_clear_expiry: true }, 'اعتبار نامحدود شد'); };
      var cl = h('button', 's-btn sm line', 'کپی لینک کارت'); cl.onclick = function () { copy(pubLink(it.slug)); };
      var pv = h('button', 's-btn sm line', 'پیش‌نمایش'); pv.onclick = function () { preview(it); };
      var rk = h('button', 's-btn sm line', 'لینک ویرایش جدید'); rk.onclick = function () {
        if (!confirm('لینک ویرایش قبلی این مشتری باطل می‌شود. ادامه؟')) return;
        Api.admin('admin_reset_key', { p_slug: it.slug }).then(function (k) { var box = h('div'); row.appendChild(box); showCreated(box, 'لینک ویرایش جدید', it.slug, k); }, handle);
      };
      var dl = h('button', 's-btn sm red', 'حذف'); dl.onclick = function () {
        if (!confirm('کارت «' + (it.label || it.slug) + '» برای همیشه حذف شود؟')) return;
        act('admin_delete', { p_slug: it.slug }, 'حذف شد');
      };
      [tg, e30, e365, nl, cl, pv, rk, dl].forEach(function (x) { b.appendChild(x); });
      row.appendChild(b); list.appendChild(row);
    });
  }

  function preview(it) {
    Api.admin('admin_view', { p_slug: it.slug }).then(function (d) {
      if (!d || !d.v) { toast('این مشتری هنوز کارتش را طراحی نکرده است', true); return; }
      var ov = h('div'); ov.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(10,15,30,.7);z-index:40;display:flex;align-items:center;justify-content:center;padding:14px';
      var box = h('div'); box.style.cssText = 'background:#fff;border-radius:18px;width:100%;max-width:440px;padding:12px';
      var fr = h('iframe', 's-pv'); fr.src = 'preview.html';
      var cl = h('button', 's-btn sm line', 'بستن'); cl.style.marginTop = '8px'; cl.onclick = function () { ov.remove(); window.removeEventListener('message', onMsg); };
      function onMsg(e) { if (e.source === fr.contentWindow && e.data && e.data.ready) fr.contentWindow.postMessage(d, '*'); }
      window.addEventListener('message', onMsg);
      box.appendChild(fr); box.appendChild(cl); ov.appendChild(box); document.body.appendChild(ov);
    }, handle);
  }

  function backup() {
    Api.admin('admin_export').then(function (rows) {
      var blob = new Blob([JSON.stringify(rows, null, 2)], { type: 'application/json' });
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      a.download = 'cards-backup-' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a); a.click(); a.remove(); toast('پشتیبان دانلود شد');
    }, handle);
  }

  function init() {
    if (!Api.configured()) { showLogin(); return; }
    if (!Api.hasSession()) { showLogin(); return; }
    Api.admin('is_admin').then(function (ok) { if (ok) showDash(); else { Api.logout(); showLogin('این حساب مدیر نیست.'); } },
      function () { showLogin('نشست شما منقضی شده؛ دوباره وارد شوید.'); });
  }
  init();
})();
