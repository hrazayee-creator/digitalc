(function () {
  'use strict';
  var root = document.getElementById('root'), subEl = document.getElementById('sub');
  var KEY = (location.hash || '').replace(/^#/, '').replace(/[^A-Za-z0-9]/g, '');
  var BASE = location.origin + location.pathname.replace(/[^\/]*$/, '');

  var LABELS = ['نام و نام‌خانوادگی', 'عنوان / سمت', 'شرکت / برند', 'معرفی کوتاه', 'شماره تماس', 'ایمیل', 'وب‌سایت',
    'اینستاگرام (آی‌دی)', 'تلگرام (آی‌دی)', 'واتساپ (شماره با کد کشور)', 'لینکدین (آی‌دی یا لینک)', 'آدرس',
    'لینک‌های دلخواه (هر خط: عنوان | آدرس)'];
  var HINTS = ['مثلاً: علی رضایی', 'مثلاً: مدیر فروش', 'نام شرکت یا برند', 'چند جمله درباره خودتان', '09123456789',
    'name@example.com', 'example.com', 'my_id', 'my_id', '989123456789', 'my-profile', 'شهر، خیابان، پلاک',
    'نمونه کارها | https://example.com/work'];
  var LTR = { 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1, 10: 1 };
  var MULTI = { 3: 1, 11: 1, 12: 1 };
  var TPL = ['شیشه‌ای تیره', 'مینیمال', 'لوکس', 'گرادیان', 'اداری', 'نرم'];
  var ACCN = ['طلایی', 'آبی', 'زمردی', 'رز', 'بنفش', 'نارنجی', 'فیروزه‌ای', 'سرمه‌ای'];
  var JOBS = [
    { n: 'پزشک / دکتر', title: 'پزشک', links: 'نوبت‌دهی | \nمقالات و آموزش | ', t: 1, a: 1 },
    { n: 'مهندس مکانیک', title: 'مهندس مکانیک', links: 'نمونه پروژه‌ها | \nرزومه | ', t: 4, a: 7 },
    { n: 'مهندس عمران / معمار', title: 'مهندس عمران و معماری', links: 'نمونه پروژه‌ها | \nدرخواست مشاوره | ', t: 4, a: 6 },
    { n: 'بنا / پیمانکار ساختمان', title: 'بنا و پیمانکار ساختمانی', links: 'نمونه کارها | \nدرخواست برآورد | ', t: 2, a: 5 },
    { n: 'وکیل / مشاور حقوقی', title: 'وکیل پایه یک دادگستری', links: 'وقت مشاوره | ', t: 2, a: 0 },
    { n: 'مشاور املاک', title: 'مشاور املاک', links: 'فایل‌های فروش | \nفایل‌های اجاره | ', t: 3, a: 3 },
    { n: 'مربی / ورزش', title: 'مربی', links: 'ثبت‌نام | \nبرنامه‌ها | ', t: 3, a: 5 },
    { n: 'عکاس / طراح', title: 'عکاس و طراح', links: 'نمونه کارها | \nسفارش پروژه | ', t: 0, a: 4 },
    { n: 'کافه / رستوران', title: 'کافه و رستوران', links: 'منو | \nثبت سفارش | ', t: 5, a: 5 },
    { n: 'آرایشگاه / زیبایی', title: 'سالن زیبایی', links: 'رزرو نوبت | \nنمونه کار | ', t: 5, a: 3 },
    { n: 'فروشگاه / کسب‌وکار', title: 'فروشگاه', links: 'کاتالوگ | \nسفارش | ', t: 0, a: 1 }
  ];

  var state = { slug: '', label: '', active: false, expires_at: null, t: 0, a: 0, v: [], p: '' };
  var inputs = [], tplBtns = [], dotBtns = [], pv, pvReady = false, dirty = false, toastTimer;

  function h(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function toast(msg, err) {
    var old = document.querySelector('.s-toast'); if (old) old.remove();
    var t = h('div', 's-toast' + (err ? ' err' : ''), msg); document.body.appendChild(t);
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.remove(); }, 3500);
  }
  function fail(msg) { subEl.textContent = ''; root.innerHTML = ''; var c = h('div', 's-card'); c.appendChild(h('p', '', msg)); root.appendChild(c); }
  function publicLink() { return BASE + '#@' + state.slug; }
  function card() { return { t: state.t, a: state.a, v: state.v.slice(), p: state.p }; }
  function sendPreview() { if (pv && pvReady && pv.contentWindow) pv.contentWindow.postMessage(card(), '*'); }
  function changed() { dirty = true; sendPreview(); }

  function statusChip() {
    var exp = state.expires_at ? new Date(state.expires_at) : null;
    if (exp && exp < new Date()) return ['bad', 'منقضی شده'];
    if (state.active) return ['ok', 'فعال'];
    return ['wait', 'در انتظار فعال‌سازی'];
  }

  function build() {
    root.innerHTML = '';
    var st = statusChip();
    subEl.textContent = 'اطلاعاتت را وارد کن و ظاهر کارت را انتخاب کن؛ نتیجه همان لحظه دیده می‌شود.';

    // link card
    var lc = h('div', 's-card');
    var top = h('div', 's-row'); top.appendChild(h('h2', '', 'لینک کارت')); top.appendChild(h('span', 's-chip ' + st[0], st[1]));
    lc.appendChild(top);
    lc.appendChild(h('div', 's-link', publicLink()));
    if (st[0] === 'wait') lc.appendChild(h('div', 's-muted', 'تا کارت فعال نشود، این لینک برای دیگران باز نمی‌شود. بعد از فعال‌سازی توسط پشتیبانی، می‌توانی لینک را به اشتراک بگذاری.'));
    if (st[0] === 'bad') lc.appendChild(h('div', 's-muted', 'اعتبار کارت تمام شده است؛ برای تمدید با پشتیبانی تماس بگیر.'));
    var lr = h('div', 's-row');
    var cp = h('button', 's-btn sm', 'کپی لینک'); cp.onclick = function () { copy(publicLink()); };
    lr.appendChild(cp);
    if (navigator.share) { var sh = h('button', 's-btn sm line', 'ارسال'); sh.onclick = function () { navigator.share({ title: state.v[0] || 'کارت دیجیتال', url: publicLink() }).catch(function () { }); }; lr.appendChild(sh); }
    lc.appendChild(lr);
    root.appendChild(lc);

    // preview
    var pc = h('div', 's-card'); pc.appendChild(h('h2', '', 'پیش‌نمایش زنده'));
    pv = h('iframe', 's-pv'); pv.src = 'preview.html'; pv.setAttribute('title', 'پیش‌نمایش');
    pc.appendChild(pv); root.appendChild(pc);

    // job + photo
    var jc = h('div', 's-card'); jc.appendChild(h('h2', '', 'شروع سریع'));
    jc.appendChild(h('label', 's-lbl', 'شغلت چیست؟ (یک پیشنهاد آماده برای عنوان، دکمه‌ها و ظاهر کارت می‌گذارد)'));
    var js = h('select', 's-sel'); js.appendChild(new Option('— انتخاب کن —', ''));
    JOBS.forEach(function (j, i) { js.appendChild(new Option(j.n, String(i))); });
    js.onchange = function () { if (js.value !== '') applyJob(JOBS[+js.value]); };
    jc.appendChild(js);
    jc.appendChild(h('label', 's-lbl', 'عکس پروفایل'));
    var pr = h('div', 's-photo'); var pimg = h('div', 'ph', 'بدون عکس'); pr.appendChild(pimg);
    var pcol = h('div'); var file = h('input'); file.type = 'file'; file.accept = 'image/*'; file.className = 's-hide';
    var pick = h('button', 's-btn sm gold', 'انتخاب عکس'); pick.onclick = function () { file.click(); };
    var rm = h('button', 's-btn sm line', 'حذف عکس'); rm.onclick = function () { state.p = ''; setPhotoUi(); changed(); };
    file.onchange = function () { if (file.files && file.files[0]) readPhoto(file.files[0]); file.value = ''; };
    var pbr = h('div', 's-row'); pbr.appendChild(pick); pbr.appendChild(rm); pcol.appendChild(pbr); pcol.appendChild(file); pr.appendChild(pcol);
    jc.appendChild(pr); root.appendChild(jc);
    function setPhotoUi() {
      var n;
      if (state.p) { n = h('img'); n.src = state.p; n.alt = ''; } else { n = h('div', 'ph', 'بدون عکس'); }
      pr.replaceChild(n, pr.firstChild); pimg = n;
    }
    root._setPhotoUi = setPhotoUi;
    setPhotoUi();

    // look
    var lk = h('div', 's-card'); lk.appendChild(h('h2', '', 'ظاهر کارت'));
    lk.appendChild(h('label', 's-lbl', 'قالب'));
    var tp = h('div', 's-tpl'); tplBtns = [];
    TPL.forEach(function (n, i) { var b = h('button', '', n); b.onclick = function () { state.t = i; refreshLook(); changed(); }; tplBtns.push(b); tp.appendChild(b); });
    lk.appendChild(tp);
    lk.appendChild(h('label', 's-lbl', 'رنگ اصلی'));
    var dt = h('div', 's-dots'); dotBtns = [];
    window.CardRender.ACC.forEach(function (c, i) { var b = h('button'); b.style.background = c[0]; b.title = ACCN[i]; b.onclick = function () { state.a = i; refreshLook(); changed(); }; dotBtns.push(b); dt.appendChild(b); });
    lk.appendChild(dt); root.appendChild(lk);
    refreshLook();

    // fields
    var fc = h('div', 's-card'); fc.appendChild(h('h2', '', 'اطلاعات کارت')); inputs = [];
    LABELS.forEach(function (lb, i) {
      fc.appendChild(h('label', 's-lbl', lb));
      var el = MULTI[i] ? h('textarea', 's-ta') : h('input', 's-in');
      if (!MULTI[i]) el.type = 'text';
      if (LTR[i]) el.className += ' s-ltr';
      el.placeholder = HINTS[i]; el.value = state.v[i] || '';
      el.oninput = function () { state.v[i] = el.value; changed(); };
      inputs.push(el); fc.appendChild(el);
    });
    root.appendChild(fc);

    var sv = h('button', 's-btn gold', 'ذخیره کارت'); sv.style.width = '100%'; sv.style.marginTop = '16px';
    sv.onclick = function () { save(sv); };
    root.appendChild(sv);
    root.appendChild(h('p', 's-muted', 'لینک ویرایش این صفحه محرمانه است؛ آن را برای کسی نفرست. اگر گمش کردی، پشتیبانی می‌تواند لینک جدید بدهد.'));

    window.addEventListener('message', function (e) {
      if (pv && e.source === pv.contentWindow && e.data && e.data.ready) { pvReady = true; sendPreview(); }
    });
  }

  function refreshLook() {
    tplBtns.forEach(function (b, i) { b.className = i === state.t ? 'on' : ''; });
    dotBtns.forEach(function (b, i) { b.className = i === state.a ? 'on' : ''; });
  }

  function applyJob(j) {
    if (!state.v[1]) { state.v[1] = j.title; inputs[1].value = j.title; }
    if (!state.v[12]) { state.v[12] = j.links; inputs[12].value = j.links; }
    state.t = j.t; state.a = j.a; refreshLook(); changed();
    toast('پیشنهاد اعمال شد؛ در «لینک‌های دلخواه» آدرس‌ها را کامل کن.');
  }

  function readPhoto(f) {
    var img = new Image(), url = URL.createObjectURL(f);
    img.onload = function () {
      var s = Math.min(img.width, img.height), sx = (img.width - s) / 2, sy = (img.height - s) / 2, out = '';
      var tries = [[320, 0.82], [280, 0.7], [240, 0.6], [200, 0.5]], i;
      for (i = 0; i < tries.length; i++) {
        var c = document.createElement('canvas'); c.width = c.height = tries[i][0];
        c.getContext('2d').drawImage(img, sx, sy, s, s, 0, 0, c.width, c.height);
        out = c.toDataURL('image/jpeg', tries[i][1]);
        if (out.length <= 55000) break;
      }
      URL.revokeObjectURL(url);
      if (out.length > 55000) { toast('حجم عکس زیاد است؛ عکس دیگری انتخاب کن', true); return; }
      state.p = out; root._setPhotoUi(); changed();
    };
    img.onerror = function () { URL.revokeObjectURL(url); toast('این فایل عکس معتبری نیست', true); };
    img.src = url;
  }

  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { toast('کپی شد'); }, function () { toast('کپی نشد؛ لینک را دستی انتخاب کن', true); });
    else toast('کپی نشد؛ لینک را دستی انتخاب کن', true);
  }

  function save(btn) {
    btn.disabled = true;
    var data = { t: state.t, a: state.a, v: state.v.map(function (x) { return (x || '').replace(/^\s+|\s+$/g, ''); }), p: state.p };
    Api.rpc('edit_save', { p_key: KEY, p_data: data }).then(function (ok) {
      btn.disabled = false;
      if (ok) { dirty = false; toast('ذخیره شد ✓'); } else toast('ذخیره نشد؛ لینک ویرایش معتبر نیست', true);
    }, function (e) { btn.disabled = false; toast('خطا در ذخیره: ' + e.message, true); });
  }

  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

  function init() {
    if (!Api.configured()) { fail('سرور هنوز تنظیم نشده است.'); return; }
    if (KEY.length < 32) { fail('لینک ویرایش معتبر نیست. از لینکی که پشتیبانی داده استفاده کن.'); return; }
    Api.rpc('edit_load', { p_key: KEY }).then(function (r) {
      if (!r) { fail('لینک ویرایش معتبر نیست یا حذف شده است.'); return; }
      var d = r.data || {}, i;
      state.slug = r.slug; state.label = r.label || ''; state.active = !!r.active; state.expires_at = r.expires_at;
      state.t = d.t >= 0 && d.t <= 5 ? d.t : 0; state.a = d.a >= 0 && d.a <= 7 ? d.a : 0; state.p = typeof d.p === 'string' ? d.p : '';
      state.v = []; for (i = 0; i < 13; i++) state.v[i] = d.v && typeof d.v[i] === 'string' ? d.v[i] : '';
      if (!state.v[0] && state.label) state.v[0] = state.label;
      build();
    }, function (e) { fail('ارتباط با سرور برقرار نشد (' + e.message + '). دوباره تلاش کن.'); });
  }
  init();
})();
